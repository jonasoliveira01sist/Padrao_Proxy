package modelo.proxy;
//Interface
public interface AudioIF {
	//M�todo Play
	public void play();

}
